#!/bin/bash

. "${1}"

echo "$INSTALLING"
sleep 2
echo "$INSTALLED"
